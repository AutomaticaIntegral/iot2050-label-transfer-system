/**
 * Script simple para iniciar el servidor híbrido modular
 * Cliente: Adisseo
 * Proyecto: TCP Label Transfer
 */

console.log('\n');
console.log('═════════════════════════════════════════════════════');
console.log('  INICIANDO SERVIDOR HÍBRIDO MODULAR - ADISSEO');
console.log('═════════════════════════════════════════════════════');
console.log('\n');

// Simplemente importa y ejecuta el archivo principal
require('./src/main');
